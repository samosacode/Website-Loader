import webbrowser
import json

json_path = "json/links.json"
operation = input("open or save: ").lower()
match operation:
  case "open":
    with open(json_path,"r") as f:
      links = json.load(f)
      to_open = input("name: ").lower()
      if to_open in links:
        url = links[to_open]
        webbrowser.open(url)
      else:
        print("not saved earlier")
  case "save":
    link = input("website link: ")
    name = input("web name: ").lower()
    with open(json_path,"r") as f2:
        linksaved = json.load(f2)
        linksaved[name] = link
    with open(json_path,"w") as f4:
        json.dump(linksaved,f4)
  case "read":
    with open(json_path,"r") as f3:
      linkread = json.load(f3)
      print(linkread)